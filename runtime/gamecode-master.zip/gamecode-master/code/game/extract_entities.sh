#! /bin/bash
awk -f extract_entities.awk *.c
